@echo off
powershell.exe -Command "Start-Process -NoNewWindow -FilePath powershell.exe -ArgumentList '-ExecutionPolicy Bypass -Command ""spicetify backup apply"""'"
pause
