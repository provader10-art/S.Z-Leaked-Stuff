sc config NcbService start=disabled
sc config jhi_service start=disabled
sc config WMIRegistrationService start=disabled
sc config "Intel(R) TPM Provisioning Service" start=disabled
sc config DeviceAssociationService start=disabled
sc config StorSvc start=disabled
sc config TieringEngineService start=disabled
sc config DPS start=disabled
sc config Themes start=disabled
pause



