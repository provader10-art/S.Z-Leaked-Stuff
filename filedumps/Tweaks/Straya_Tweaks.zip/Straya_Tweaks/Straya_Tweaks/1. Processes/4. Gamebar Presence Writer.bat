@echo off
CD /D %HOMEDRIVE%%HOMEPATH%\Desktop
echo %CD%

REM ************ Main process *****************

set "fileToDelete=%SystemRoot%\System32\GameBarPresenceWriter.exe"

if exist "%fileToDelete%" (
    echo *** Taking ownership of the file ***
    takeown /F "%fileToDelete%"
    
    echo *** Adjusting permissions ***
    icacls "%fileToDelete%" /grant administrators:F

    echo *** Removing Gamebar Presence Writer ***
    del "%fileToDelete%" /s /f /q
    echo File deleted successfully.
) else (
    echo File not found: %fileToDelete%
)

pause
